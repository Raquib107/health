A Pen created at CodePen.io. You can find this one at http://codepen.io/bigglesrocks/pen/XbGGEE.

 Clean profile/identification card UI