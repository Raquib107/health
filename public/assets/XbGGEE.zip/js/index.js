$('.info dd').each(function() {
  $(this).css({width: $(this).text()+'%'});
});